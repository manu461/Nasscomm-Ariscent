CREATE PROCEDURE mycustomer.INSERTNEWCUSTOMER(IN id      VARCHAR(4), IN fName VARCHAR(10), IN lName VARCHAR(10),
                                              IN contact VARCHAR(10), IN password VARCHAR(10), IN gender VARCHAR(5))
  BEGIN
    INSERT INTO customerTable VALUES (id,fName,lName,contact,password,gender);
  END;
