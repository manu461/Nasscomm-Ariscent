CREATE PROCEDURE mycustomer.INSERTDATACUSTOMER(IN id      VARCHAR(5), IN fName VARCHAR(10), IN lName VARCHAR(10),
                                               IN contact VARCHAR(10), IN password VARCHAR(10))
  BEGIN
    INSERT INTO customer VALUES (id,fName,lName,contact,password);
  END;
