CREATE PROCEDURE mycustomer.INSERTDATA(IN id      VARCHAR(5), IN fName VARCHAR(10), IN lName VARCHAR(10),
                                       IN contact VARCHAR(10), IN password VARCHAR(10))
  BEGIN
    INSERT INTO customer VALUE (myCustomer.customer.id,myCustomer.customer.fName,myCustomer.customer.lName,myCustomer.customer.contact,myCustomer.customer.password);
  END;
